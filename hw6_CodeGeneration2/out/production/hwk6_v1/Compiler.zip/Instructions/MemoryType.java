package Instructions;

public enum MemoryType {
    Alloca,
    Load,
    Store,
    Getelementptr,
    Phi,
    ZextTo,
}
