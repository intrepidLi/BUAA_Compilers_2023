package Type;

public abstract class Type {
}
