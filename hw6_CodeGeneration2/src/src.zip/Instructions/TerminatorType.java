package Instructions;

public enum TerminatorType {
    RetWithVal,
    RetNoVal,
    BrNoCondition,
    BrWithCondition,
    CallWithVal,
    CallNoVal,
}
