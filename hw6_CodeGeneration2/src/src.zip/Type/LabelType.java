package Type;

public class LabelType extends Type{
    public String toString() {
        return "label";
    }
}
