package EntryType;

public class ConstVar {
    private int value;

    public ConstVar(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
