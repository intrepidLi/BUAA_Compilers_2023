package EntryType;

public class FuncParam {
    public int type; // 0: int, 1: int[], 2: int[][]

    public int getType() {
        return type;
    }
}
