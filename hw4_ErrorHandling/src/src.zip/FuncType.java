public enum FuncType {
    VoidFunc,
    IntFunc,
    MainFunc,
    NotFunc,
}
