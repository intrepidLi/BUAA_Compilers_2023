package Instructions;

public enum TerminatorType {
    RetWithVal,
    RetNoVal,
    Br,
    CallWithVal,
    CallNoVal,
}
