package Values.Constants;

import Type.ArrayType;

public class ConstantArray extends Constant{
    public ConstantArray(ArrayType arrayType) {
        super(null, arrayType, null);
    }
}
