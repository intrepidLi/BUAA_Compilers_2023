package Type;

public class LabelType extends Type{
}
