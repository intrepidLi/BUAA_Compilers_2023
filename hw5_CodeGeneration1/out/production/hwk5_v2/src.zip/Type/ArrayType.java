package Type;

public class ArrayType extends Type {

}
